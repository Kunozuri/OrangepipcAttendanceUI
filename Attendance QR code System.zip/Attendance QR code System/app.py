from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Default route
@app.route('/')
def index():
    return redirect('/login')

# Login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # ADD QUERY HERE

        if username == 'admin' and password == 'admin':
            return redirect('/home')
        else:
            return "Invalid credentials", 401
        
    return render_template('login.html')

# Home page
@app.route('/home', methods=['GET'])
def home():
    
    # ADD OTHER THINGS HERE SPECIALLY MENU
    
    return render_template('home.html')

if __name__ == '__main__':
    app.run(debug=True)


# Signup page

# Forgot page